
import React, { useState,useEffect } from "react";
import axios from "axios";
import * as FileSaver from 'file-saver';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Header from "../Header/Header";
import Cookies from "js-cookie";
import { Stack, Box, Button, Typography, TextField,IconButton,AppBar,Toolbar} from "@mui/material";
import PPT from "../../assets/ppt-png-img.png";
import { useThemeContext } from "../ThemeContext/ThemeContext";
import { Close } from "@mui/icons-material";
import SideHeader from "../Header/SideHeader";

export default function AllFiles() {
  const [selectedFile, setSelectedFile] = useState(null);
  const [filePreviews, setFilePreviews] = useState([]);
  const data = useThemeContext()

  // useEffect(() => {
  //   const jwtToken = Cookies.get("token");
  //   if (jwtToken === undefined) {
  //     window.location.href = "/login"
  //   }
  // }, [undefined])

  const onFileChange = (e) => {

    const files = e.target.files;
    console.log("files", files)
    // setSelectedFile(files[0]); 
    // toast.success("File uploaded",{
    //   autoClose: 1000
    // });
    // displayImagePreviews(files)
    if (files) {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (
          ( file.type === "application/pdf")
        ) {
          setSelectedFile(file); 
          toast.success("File uploaded",{
            autoClose: 1000
          });
          displayImagePreviews(file)
        } else {
            alert("Not Accepted this Type ");
        //   toast.warning(
        //     "Please Upload (PNG or ZIP or PPTX) files up to 1MB each",
        //   );
       
        }
      }
    }
    
  };
 
  const onSubmit = async (e) => {
    e.preventDefault();
    console.log("hello")
 

  };

  const handleDragOver = (event) => {
    event.preventDefault();
  };

  const handleDragFiles = (event) => {
    event.preventDefault();
    const files = event.dataTransfer.files;
    console.log("drag files", files)
    // setSelectedFile(files);
    //       toast.success("File uploaded");
    //       displayImagePreviews(files)
    if (files) {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (
          (
            file.type === "application/pdf") 
         
          //   &&
          // (file.size <= 1024 * 1024)
        ) {
          setSelectedFile(file);
          toast.success("File uploaded");
          displayImagePreviews(file)
        } else {
          toast.warning(
            "Please drag PDF files up to 1MB each",
          );
        }
      }
    }
  };

  const handleFileUpload = () => {
    document.getElementById("fileInput").click();
  }

  const displayImagePreviews = (files) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      setFilePreviews(event.target.result);
    };
    // reader.readAsDataURL(files[0]);
    if (files && files.length > 0) {
      const file = files[0];
      reader.readAsDataURL(file);
    }
  };

  const CloseButton=()=>{
    setSelectedFile(null)
  }

  return (
    <Box display={"flex"} justifyContent={"center"} alignItems={"flex-end"}>   
      <SideHeader/>     
      <ToastContainer  position="bottom-right"/>     
      <Box component="form" onSubmit={onSubmit} className={data.theme?"head":"body"}  >
        <Stack className="fileupload-row" >
         
             <Typography p={1} variant="h3" sx={{color:data.theme?"head":"#1b386e"}}>Convert Pdf Files to Word Files</Typography>
            <Stack className="dropzone1"
              onClick={handleFileUpload}
              onDrop={handleDragFiles}
              onDragOver={handleDragOver}
              >
              <TextField
                id="fileInput"
                type="file"
                onChange={onFileChange}
                accept="application/pdf"
                style={{ display: "none" }}
      
              />
              <Stack display={"flex"} alignItems={"center"}>
                {/* <Typography variant="h5">Drop images that have tables, or select ZIP/PPTX files.</Typography> */}
                <img src={PPT} alt="logo"  />
                <Typography variant="body1" className="sub-title">
                  Please drag and drop PDF File here to convert Word File
                </Typography>
              </Stack>
             
            </Stack>

            
       
            {/* {
              selectedFile ?
                <Stack spacing={2} sx={{ display: "flex", alignItems: "center",justifyContent:"center", mt: "1rem" }}  >
                  {selectedFile.type.startsWith("image/") ? <img src={filePreviews} alt={'Preview'} width={"400px"} height={"300px"} /> : null}
                  <Typography variant="p"><b>File Name : </b>{selectedFile?.name}</Typography>
                  <Typography variant="p"><b>File Size : </b>{(selectedFile.size / 1024).toFixed(2)} {""} KB</Typography>
                  

                </Stack> : null
            } */}

        </Stack>
        <Stack direction={"column"} justifyContent={"center"} alignItems={"center"}>
          <Typography variant="h6">OR</Typography> 
          <Typography paragraph>Please upload the PDF file which you want to convert Word File</Typography>
        {
selectedFile ?
(
  <Stack spacing={2} sx={{ display: "flex", alignItems: "center",justifyContent:"center"}} >
      <Stack direction={"row"} alignItems={"center"} justifyContent={"space-around"} className="name-background">
  <Typography paragraph mb={0} mr={2}>{selectedFile?.name}</Typography>
  <IconButton onClick={CloseButton}>
              <Close />
            </IconButton>
  </Stack>
  <Button type="submit" variant="contained"  sx={{ width: "300px" }}  className="download-button"    >{ "Convert to Word" }</Button></Stack>
):<Button variant="contained" sx={{ width: "300px"  }}  className="download-button" htmlFor="fileInput" onClick={handleFileUpload}>Upload</Button>
        }
     
      </Stack>
      </Box>
    </Box>
    
  );
}














