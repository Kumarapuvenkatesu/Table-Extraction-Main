import React from "react";
import { Box, Stack, Typography,tableContainer,Table,TableHead,TableCell,TableRow } from "@mui/material";
import SideHeader from "../Header/SideHeader";
import FileCopyIcon from '@mui/icons-material/FileCopy';

export default function DashBoard(){
    const data = [
        { number: 90, title: 'My Asset Documents', icon: <FileCopyIcon fontSize="large" /> },
        { number: 60, title: 'Image to Table Extracted', icon: <FileCopyIcon fontSize="large" /> },
        { number: 30, title: 'PDF to Word Documents', icon: <FileCopyIcon fontSize="large" /> },
      ];
    return(
        <Box display={"flex"} justifyContent={"flex-start"} alignItems={"flex-end"}>
            <SideHeader/> 
            <Box width={"100%"}>
            <Box display="flex" justifyContent="space-between" alignContent="center">
      {data.map((item, index) => (
        <Stack
          key={index}
          m="1rem"
          mt="5rem"
          direction="row"
          alignItems="center"
          sx={{ background: "#c4e6f3", height: "175px", width: "334px" }}
        >
          <Stack sx={{ background: "#fff" }} m={1}>
            {item.icon}
          </Stack>
          <Stack direction="column" m={2}>
            <Typography variant="h5">{item.number}</Typography>
            <Typography>{item.title}</Typography>
          </Stack>
        </Stack>
      ))}
    </Box>
              <Box>
                <Stack>
                    <Typography variant="h5" style={{borderBottom:"1px solid grey",padding:"10px"}} >Recent Files</Typography>
                    <tableContainer>
                        <Table>
                            <TableHead>
                                <TableRow>
                                    <TableCell>File Name</TableCell>
                                    <TableCell>File Type</TableCell>
                                    <TableCell>Date and Time</TableCell>
                                </TableRow>
                            </TableHead>
                        </Table>
                    </tableContainer>
                </Stack>
              </Box>
            </Box>
        </Box>
    )
}