import React, { useState, useContext } from 'react';
import Drawer from '@mui/material/Drawer';
import Divider from '@mui/material/Divider';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import List from '@mui/material/List';
import { Box, Stack, Toolbar } from '@mui/material';
import { AppBar, Typography } from '@mui/material';
import { Dashboard } from '@mui/icons-material';
import { ExpandMore, ExpandLess } from "@mui/icons-material";
import { Collapse } from "@mui/material";
import { NavLink } from 'react-router-dom';
import CalculateIcon from '@mui/icons-material/Calculate';
import ThemeMode from './ThemeMode';
import TextHeader from './TextHeader';

const drawerWidth = 240;

export default function SideHeader() {
  const [open, setOpen] = useState(true);
  const [tools, setTools] = useState(true);
  const [assets, setAssets] = useState(true);
  const [activeItem, setActiveItem] = useState("");

  const handleClick = () => {
    setOpen(!open);
  };

  const handleAutomatic = () => {
    setTools(!tools);
  }

  const handleAssets = () => {
    setAssets(!assets);
  }

  return (
    <>
      <TextHeader />

      <Drawer
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: drawerWidth,
            boxSizing: 'border-box',
            backgroundColor: '#dae1f1',
          },
        }}
        variant="permanent"
        anchor="left"
      >
        <Toolbar sx={{ cursor: "Pointer" }}>
          <Typography variant='h5'>TECH TOOLS</Typography>
        </Toolbar>
        <Divider />
        <Stack sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "space-between",
          height: "100%"
        }}>
          <List >
            <List component="li" disablePadding sx={{my:"12px"}}>
              <ListItemButton component={NavLink} to="/"  >
                <ListItemIcon>
                  <Dashboard />
                  <ListItemText primary="Dashboard" />
                </ListItemIcon>
              </ListItemButton>
            </List>
            <List component="li" disablePadding sx={{my:"15px"}}>
            <ListItemButton onClick={handleClick} >
              <Typography paragraph mb={0}>AI Tools</Typography>
              {open ? <ExpandMore /> : <ExpandLess />}
            </ListItemButton>
            <Collapse in={open} >
              <List component="li" disablePadding>
                <ListItemButton component={NavLink} to="/table-extraction"  >
                  <ListItemText primary="Table Extracter" />
                </ListItemButton>
                <ListItemButton component={NavLink} to="/math-convertor" >
                  <CalculateIcon />
                  <ListItemText primary="Math Convertor" />
                </ListItemButton>
              </List>
            </Collapse>
            </List>
            <List component="li" disablePadding sx={{my:"15px"}}>
            <ListItemButton onClick={handleAutomatic}>
              <Typography paragraph mb={0}>Automatic Tools</Typography>
              {tools ? <ExpandMore /> : <ExpandLess />}
            </ListItemButton>
            <Collapse in={tools} >
              <List component="li" disablePadding>
                <ListItemButton component={NavLink} to="/pdf-to-word"  >
                  <ListItemText primary="PDF to Word" />
                </ListItemButton>
              </List>
            </Collapse>
            </List>
            <List component="li" disablePadding sx={{my:"15px"}}>
            <ListItemButton onClick={handleAssets}>
              <Typography paragraph mb={0}>Assets</Typography>
              {assets ? <ExpandMore /> : <ExpandLess />}
            </ListItemButton>
            <Collapse in={assets} >
              <List component="li" disablePadding>
                <ListItemButton component={NavLink} to="/received-files" >
                  <ListItemText primary="Received Files" />
                </ListItemButton>
              </List>
            </Collapse>
            </List>
          </List>

          <ThemeMode />
        </Stack>

      </Drawer>
    </>
  )
}